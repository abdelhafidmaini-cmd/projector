package com.projector.home

import android.graphics.drawable.Drawable

data class AppItem(
    val label: String,
    val packageName: String,
    val icon: Drawable?,
    val isAddButton: Boolean = false
)
